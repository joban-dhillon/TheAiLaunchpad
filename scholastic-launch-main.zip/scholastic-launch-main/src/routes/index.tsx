import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Compass,
  Layers,
  Sparkles,
  CheckCircle2,
  Award,
  Users,
  BookOpen,
  ArrowRight,
  MapPin,
  Star,
  TrendingUp,
  AlertTriangle,
  Target,
} from "lucide-react";
import { CTAButton } from "@/components/CTAButton";
import { Section, SectionHeader } from "@/components/Section";
import { FinalCTA } from "@/components/FinalCTA";
import { HeroSlideshow } from "@/components/HeroSlideshow";
import { useBookFreeSession } from "@/components/BookFreeSessionModal";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { parentFaqs } from "@/data/faqs";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AI & Coding for Grades 8–12 | The AI Launchpad — Brampton & GTA" },
      {
        name: "description",
        content:
          "Give your child a real edge in an AI-driven future. Practical AI, coding, and project skills for grades 8–12 in Brampton, Peel & the GTA.",
      },
      { property: "og:title", content: "AI & Coding for Grades 8–12 — The AI Launchpad" },
      {
        property: "og:description",
        content:
          "Schools aren't moving fast enough. We help students build practical AI, coding, and project skills now.",
      },
    ],
  }),
  component: HomePage,
});

const heroSlides = [
  {
    src: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80",
    label: "Small batches",
  },
  {
    src: "https://images.unsplash.com/photo-1573166364524-d9dbfd8bbf83?auto=format&fit=crop&w=1200&q=80",
    label: "Hands-on projects",
  },
  {
    src: "https://images.unsplash.com/photo-1531497865144-0464ef8fb9a9?auto=format&fit=crop&w=1200&q=80",
    label: "1:1 mentorship",
  },
  {
    src: "https://images.unsplash.com/photo-1584697964358-3e14ca57658b?auto=format&fit=crop&w=1200&q=80",
    label: "Real skills, no theory",
  },
];

function HomePage() {
  const { open: openBookSession } = useBookFreeSession();
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-border bg-surface-muted">
        <div
          aria-hidden
          className="absolute inset-0 opacity-[0.5]"
          style={{
            backgroundImage:
              "radial-gradient(circle at 1px 1px, oklch(0.32 0.08 255 / 0.08) 1px, transparent 0)",
            backgroundSize: "28px 28px",
          }}
        />
        <div className="container-prose relative py-16 sm:py-20 lg:py-24">
          <div className="grid items-center gap-12 md:grid-cols-2 md:gap-12 lg:gap-16">
            {/* LEFT: Copy */}
            <div>
              <span className="eyebrow">
                <MapPin className="h-3.5 w-3.5" /> Brampton · Peel · GTA
              </span>
              <p className="mt-5 text-sm font-bold uppercase tracking-[0.18em] text-secondary">
                AI & Coding Programs for Grades 8–12
              </p>
              <h1 className="h1 mt-4">
                Give your child a real edge in an{" "}
                <span className="text-secondary">AI-driven future.</span>
              </h1>
              <p className="lede mt-6">
                Schools are not moving fast enough. We help students build practical AI, coding,
                and project skills now — so they're ahead, not catching up.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <button
                  type="button"
                  onClick={openBookSession}
                  className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-6 py-4 text-base font-semibold text-primary-foreground shadow-sm transition hover:bg-primary/90 focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  Book Free Session
                  <ArrowRight className="h-4 w-4" />
                </button>
                <CTAButton to="/programs" variant="ghost" className="px-6 py-4 text-base">
                  Explore Programs
                </CTAButton>
              </div>
              <p className="mt-6 text-sm font-medium text-foreground/70">
                1-on-1 guidance · Real projects · Real future-ready skills
              </p>
            </div>

            {/* RIGHT: Auto-playing slideshow */}
            <HeroSlideshow slides={heroSlides} />
          </div>
        </div>
      </section>

      {/* QUICK CREDIBILITY STRIP */}
      <section className="border-b border-border bg-primary text-primary-foreground">
        <div className="container-prose grid gap-4 py-6 text-sm sm:grid-cols-2 lg:grid-cols-4">
          {[
            "Microsoft Certified AI Engineer mentors",
            "Project & portfolio-based learning",
            "Built for grades 8–12",
            "Local — Brampton, Peel & GTA",
          ].map((t) => (
            <div key={t} className="flex items-start gap-2.5">
              <CheckCircle2 className="mt-0.5 h-5 w-5 flex-shrink-0 text-secondary" />
              <span className="font-medium text-primary-foreground/90">{t}</span>
            </div>
          ))}
        </div>
      </section>



      {/* WHY PARENTS ARE ACTING NOW */}
      <Section bg="muted">
        <SectionHeader
          eyebrow="Why parents are acting now"
          title="The gap is widening. Early movers win."
          description="AI is changing how students learn, work, and compete. While most schools still teach for yesterday's world, forward-thinking parents are helping their children build real AI and coding skills now."
        />
        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {[
            {
              icon: AlertTriangle,
              title: "Schools are behind",
              body: "Most students aren't being taught how to use AI tools, build projects, or think practically about the future of work.",
              tone: "warn",
            },
            {
              icon: TrendingUp,
              title: "Early movers win",
              body: "Students who start now build confidence, portfolios, and real-world skills before everyone else catches up.",
              tone: "secondary",
            },
            {
              icon: Target,
              title: "We fill the gap",
              body: "The AI Launchpad gives students structured guidance, hands-on learning, and mentorship designed for the AI era.",
              tone: "primary",
            },
          ].map((c) => (
            <div
              key={c.title}
              className="relative overflow-hidden rounded-2xl border border-border bg-surface p-7 transition hover:shadow-md"
            >
              <span
                className={`flex h-12 w-12 items-center justify-center rounded-xl ${
                  c.tone === "warn"
                    ? "bg-gold/20 text-foreground"
                    : c.tone === "secondary"
                      ? "bg-secondary text-secondary-foreground"
                      : "bg-primary text-primary-foreground"
                }`}
              >
                <c.icon className="h-6 w-6" />
              </span>
              <h3 className="h3 mt-5 text-primary">{c.title}</h3>
              <p className="mt-3 text-foreground/75">{c.body}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* THREE LEARNING PATHWAYS — TIGHT */}
      <Section bg="default">
        <SectionHeader
          eyebrow="Three learning pathways"
          title="One clear next step for your child."
          description="Pick the path that fits — or let us recommend it on a free call."
        />
        <div className="mt-16 grid gap-8 lg:grid-cols-3 lg:items-stretch">
          <PathCard
            label="University-Bound"
            icon={Award}
            title="University Accelerator"
            subtitle="Projects, certifications, and portfolio-building for ambitious students."
            bullets={[
              "Real AI & coding projects for university applications",
              "Microsoft & Google AI certifications",
              "1:1 mentorship + hackathon prep",
            ]}
            ctaLabel="Start Your University Path"
            featured
          />
          <PathCard
            label="Tailored 1:1"
            icon={Compass}
            title="Personalized Learning"
            subtitle="1:1 coaching tailored to your child's pace, goals, and skill level."
            bullets={[
              "Custom learning plan from session one",
              "Faster progress than any group class",
              "Personal capstone project",
            ]}
            ctaLabel="Book a Discovery Call"
          />
          <PathCard
            label="Start Strong"
            icon={Layers}
            title="Foundations Pathway"
            subtitle="A clear, structured start in AI and coding for new learners."
            bullets={[
              "Python & AI fundamentals through mini-projects",
              "Beginner → Intermediate → Expert progression",
              "Guided by a Microsoft Certified AI Engineer",
            ]}
            ctaLabel="Explore the Foundations"
          />
        </div>
      </Section>

      {/* HOW IT WORKS */}
      <Section bg="muted">
        <SectionHeader
          eyebrow="How it works"
          title="A simple, four-step process."
          description="No guesswork. Just a clear path from your first conversation to your child's first project."
        />
        <div className="mt-16 grid gap-10 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
          {[
            { n: "01", t: "Book a Free Session", d: "Tell us about your child's grade, interests, and goals." },
            { n: "02", t: "Find the Right Path", d: "We recommend the program that fits your child best." },
            { n: "03", t: "Learn Through Guided Sessions", d: "Structured learning with experienced mentors." },
            { n: "04", t: "Build Projects & Confidence", d: "Real projects, real progress, real outcomes." },
          ].map((s, i, arr) => (
            <div key={s.n} className="relative">
              <div className="flex items-center gap-4">
                <span
                  className="flex h-16 w-16 flex-shrink-0 items-center justify-center rounded-2xl text-primary-foreground font-display text-2xl font-bold shadow-md"
                  style={{
                    background:
                      "linear-gradient(135deg, var(--secondary), var(--success-glow))",
                  }}
                >
                  {s.n}
                </span>
                {i < arr.length - 1 && (
                  <span
                    aria-hidden
                    className="hidden lg:flex flex-1 items-center text-secondary/50"
                  >
                    <span className="h-px flex-1 bg-gradient-to-r from-secondary/40 to-secondary/10" />
                    <ArrowRight className="h-5 w-5 -ml-1" />
                  </span>
                )}
              </div>
              <h3 className="h3 mt-5">{s.t}</h3>
              <p className="mt-2 text-foreground/75">{s.d}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* WHY PARENTS CHOOSE US */}
      <Section bg="default">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-start lg:gap-16">
          <div>
            <span className="eyebrow">Why parents choose us</span>
            <h2 className="h2 mt-4">Serious learning. Designed by experts. Made for students.</h2>
            <p className="lede mt-5">
              We're not a generic tutoring service. The AI Launchpad gives students the same
              tools and frameworks used by professionals — taught in a way that's structured,
              encouraging, and age-appropriate.
            </p>
          </div>
          <ul className="grid gap-4 sm:grid-cols-2">
            {[
              { i: Users, t: "Built by industry experts" },
              { i: Sparkles, t: "Real AI tools used by professionals" },
              { i: BookOpen, t: "Project-based learning" },
              { i: Compass, t: "Clear pathways, not random classes" },
              { i: Award, t: "Google, IBM & Microsoft certifications" },
              { i: MapPin, t: "Local — Brampton & the GTA" },
            ].map((x) => (
              <li
                key={x.t}
                className="flex items-start gap-3 rounded-lg border border-border bg-surface p-5"
              >
                <span className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-md bg-accent text-primary">
                  <x.i className="h-4.5 w-4.5" />
                </span>
                <span className="text-sm font-medium text-foreground/85">{x.t}</span>
              </li>
            ))}
          </ul>
        </div>
      </Section>

      {/* TRUST */}
      <Section bg="muted">
        <SectionHeader
          eyebrow="Trusted by parents"
          title="Local roots. Industry expertise. Student outcomes."
          align="center"
        />
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {[
            {
              q: "I wanted my son to actually understand AI, not just hear about it. The structure here finally gave him direction.",
              a: "Parent · Grade 10 student",
            },
            {
              q: "The instructors clearly know the field. My daughter built her first real project in just a few weeks.",
              a: "Parent · Grade 9 student",
            },
            {
              q: "Worth every conversation. We knew exactly what path made sense after our free session.",
              a: "Parent · Grade 11 student",
            },
          ].map((t, i) => (
            <figure
              key={i}
              className="rounded-xl border border-border bg-surface p-7"
            >
              <div className="flex gap-1" style={{ color: "var(--gold)" }}>
                {Array.from({ length: 5 }).map((_, j) => (
                  <Star key={j} className="h-4 w-4 fill-current" />
                ))}
              </div>
              <blockquote className="mt-4 text-foreground/85">"{t.q}"</blockquote>
              <figcaption className="mt-5 text-sm font-medium text-muted-foreground">
                — {t.a}
              </figcaption>
            </figure>
          ))}
        </div>
        <p className="mt-8 text-center text-xs text-muted-foreground">
          Sample testimonials shown — real parent reviews will be added as our program grows.
        </p>
      </Section>

      {/* FAQ TEASER */}
      <Section bg="default">
        <div className="grid gap-10 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-5">
            <span className="eyebrow">Parent FAQs</span>
            <h2 className="h2 mt-4">Questions parents ask us.</h2>
            <p className="lede mt-5">
              Quick answers to the most common questions. See the full list on our About page.
            </p>
            <Link
              to="/about"
              hash="parent-faqs"
              className="mt-7 inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-sm transition hover:bg-primary/90"
            >
              View All FAQs <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="lg:col-span-7">
            <div className="rounded-2xl border border-border bg-surface p-2 sm:p-4">
              <Accordion type="single" collapsible className="w-full">
                {parentFaqs.slice(0, 3).map((f, i) => (
                  <AccordionItem
                    key={i}
                    value={`home-faq-${i}`}
                    className="border-border last:border-b-0"
                  >
                    <AccordionTrigger className="text-left text-base font-semibold text-primary hover:no-underline px-3 sm:px-4">
                      {f.q}
                    </AccordionTrigger>
                    <AccordionContent className="text-foreground/80 px-3 sm:px-4 leading-relaxed">
                      {f.a}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </div>
      </Section>

      <FinalCTA />
    </>
  );
}

function PathCard({
  label,
  icon: Icon,
  title,
  subtitle,
  bullets,
  ctaLabel,
  featured,
}: {
  label: string;
  icon: typeof Award;
  title: string;
  subtitle: string;
  bullets: string[];
  ctaLabel: string;
  featured?: boolean;
}) {
  const { open: openBookSession } = useBookFreeSession();
  return (
    <div
      className={`relative flex flex-col rounded-2xl bg-surface p-7 transition ${
        featured
          ? "border-2 border-secondary shadow-xl ring-4 ring-secondary/15 lg:-mt-4 lg:scale-[1.03] lg:p-8"
          : "border border-border hover:border-secondary/40 hover:shadow-md"
      }`}
      style={
        featured
          ? { boxShadow: "0 20px 50px -20px color-mix(in oklab, var(--secondary) 45%, transparent)" }
          : undefined
      }
    >
      {featured && (
        <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-secondary px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-secondary-foreground shadow-md">
          ⭐ Most Popular
        </span>
      )}
      <div className="flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <Icon className="h-5 w-5" />
        </span>
        <span className="text-[11px] font-bold uppercase tracking-wider text-secondary">
          {label}
        </span>
      </div>
      <h3 className="h3 mt-5 text-primary">{title}</h3>
      <p className="mt-2 text-sm font-medium text-foreground/80">{subtitle}</p>

      <ul className="mt-6 space-y-2.5">
        {bullets.map((b) => (
          <li key={b} className="flex items-start gap-2.5 text-sm text-foreground/85">
            <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-secondary" />
            <span>{b}</span>
          </li>
        ))}
      </ul>

      <div className="mt-6 flex-1" />
      <button
        type="button"
        onClick={openBookSession}
        className={`mt-2 inline-flex items-center justify-center gap-2 rounded-lg px-5 py-3 text-sm font-semibold transition ${
          featured
            ? "bg-secondary text-secondary-foreground hover:opacity-90 shadow-md"
            : "border border-border bg-surface text-primary hover:border-secondary hover:text-secondary"
        }`}
      >
        {ctaLabel} <ArrowRight className="h-4 w-4" />
      </button>
    </div>
  );
}
