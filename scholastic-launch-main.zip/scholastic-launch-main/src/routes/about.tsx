import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { Heart, Target, Users, Sparkles, MapPin, GraduationCap } from "lucide-react";
import { Section } from "@/components/Section";
import { FinalCTA } from "@/components/FinalCTA";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { parentFaqs } from "@/data/faqs";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — The AI Launchpad | Brampton & GTA" },
      {
        name: "description",
        content:
          "Built by industry experts to give students in Brampton and the GTA a real, structured path into AI and coding. Learn about our mission and approach.",
      },
      { property: "og:title", content: "About — The AI Launchpad" },
      {
        property: "og:description",
        content:
          "Real tools. Real guidance. Real outcomes. The story behind The AI Launchpad.",
      },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.location.hash === "#parent-faqs") {
      requestAnimationFrame(() => {
        document.getElementById("parent-faqs")?.scrollIntoView({ behavior: "smooth" });
      });
    }
  }, []);

  return (
    <>
      {/* Hero */}
      <section className="border-b border-border bg-surface-muted">
        <div className="container-prose py-20 sm:py-28 max-w-4xl">
          <span className="eyebrow">About</span>
          <h1 className="h1 mt-5">Built for serious students. Trusted by parents.</h1>
          <p className="lede mt-6">
            The AI Launchpad exists to give students something they can't easily find elsewhere:
            a structured, expert-built path into AI and coding — taught with real tools and real
            guidance, in a supportive local environment.
          </p>
        </div>
      </section>

      {/* Founder story */}
      <Section bg="default">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-5">
            <span className="eyebrow">Our story</span>
            <h2 className="h2 mt-4">Why we started The AI Launchpad.</h2>
          </div>
          <div className="lg:col-span-7 space-y-5 text-foreground/85 leading-relaxed">
            <p>
              We kept seeing the same pattern: students who were curious about AI and coding,
              but had no clear way in. Generic tutoring services taught syntax. YouTube tutorials
              were scattered. Most online courses weren't built for high school students at all.
            </p>
            <p>
              The AI Launchpad was created to fix that. We brought together industry experts —
              people who actually use AI tools in their work — to design a program made
              specifically for grades 8 through 12. Structured. Practical. Local.
            </p>
            <p>
              Our goal is simple: help students build skills that genuinely matter, in a way
              parents can understand and trust.
            </p>
          </div>
        </div>
      </Section>

      {/* Mission + philosophy */}
      <Section bg="muted">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Pillar
            icon={Target}
            title="Our mission"
            body="To help students in grades 8–12 build real, future-ready AI and coding skills through structured, expert-led learning."
          />
          <Pillar
            icon={Heart}
            title="Our philosophy"
            body="Real tools. Real guidance. Real outcomes. We don't water things down — we make them clear."
          />
          <Pillar
            icon={Users}
            title="Our approach"
            body="We meet students where they are, give them a path forward, and walk alongside them as they grow."
          />
        </div>
      </Section>

      {/* What makes us different */}
      <Section bg="default">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-5">
            <span className="eyebrow">Different by design</span>
            <h2 className="h2 mt-4">Industry-aligned, not generic.</h2>
            <p className="lede mt-5">
              The difference between learning to code and learning to build is enormous. We focus
              on the second.
            </p>
          </div>
          <div className="lg:col-span-7 space-y-6">
            <Diff
              title="Built by industry, not adapted from textbooks"
              body="Our curriculum reflects how AI and coding are actually used by professionals — not academic theory disconnected from real work."
            />
            <Diff
              title="Structured pathways, not random classes"
              body="Students follow a clear plan with measurable progress, not a disconnected series of one-off lessons."
            />
            <Diff
              title="Encouraging, supportive learning"
              body="High standards, paired with patience and warmth. Students grow because they feel supported."
            />
          </div>
        </div>
      </Section>

      {/* Local */}
      <Section bg="muted">
        <div className="rounded-2xl border border-border bg-surface p-10 sm:p-14">
          <div className="grid gap-10 lg:grid-cols-3 lg:gap-14">
            <Pillar
              icon={MapPin}
              title="Service area"
              body="Proudly serving students and families across Brampton, Peel Region, and the broader Greater Toronto Area."
            />
            <Pillar
              icon={GraduationCap}
              title="Grades served"
              body="We work with students in grades 8 through 12 — meeting each student at the right level for them."
            />
            <Pillar
              icon={Sparkles}
              title="A supportive environment"
              body="We hold high expectations and support students at every step. No pressure. No comparison. Just steady growth."
            />
          </div>
        </div>
      </Section>

      {/* Parent FAQs */}
      <Section bg="default">
        <div id="parent-faqs" className="scroll-mt-24">
          <div className="max-w-3xl">
            <span className="eyebrow">FAQs</span>
            <h2 className="h2 mt-4">Parent FAQs</h2>
            <p className="lede mt-5">
              Answers to the questions parents ask us most often.
            </p>
          </div>
          <div className="mt-10 max-w-3xl rounded-2xl border border-border bg-surface p-2 sm:p-4">
            <Accordion type="single" collapsible className="w-full">
              {parentFaqs.map((f, i) => (
                <AccordionItem key={i} value={`item-${i}`} className="border-border last:border-b-0">
                  <AccordionTrigger className="text-left text-base font-semibold text-primary hover:no-underline px-3 sm:px-4">
                    {f.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-foreground/80 px-3 sm:px-4 leading-relaxed">
                    {f.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </Section>

      <FinalCTA
        title="Ready to take the next step?"
        description="Book a free session. We'll talk through your child's interests and recommend the path that fits."
      />
    </>
  );
}

function Pillar({
  icon: Icon,
  title,
  body,
}: {
  icon: typeof Target;
  title: string;
  body: string;
}) {
  return (
    <div>
      <span className="flex h-11 w-11 items-center justify-center rounded-md bg-accent text-primary">
        <Icon className="h-5 w-5" />
      </span>
      <h3 className="h3 mt-5">{title}</h3>
      <p className="mt-3 text-foreground/80">{body}</p>
    </div>
  );
}

function Diff({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-xl border border-border bg-surface p-6">
      <h3 className="h3">{title}</h3>
      <p className="mt-2 text-foreground/80">{body}</p>
    </div>
  );
}
