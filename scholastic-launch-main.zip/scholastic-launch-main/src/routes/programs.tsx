import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Award, Compass, Layers, CheckCircle2, ChevronDown, ArrowRight, Star } from "lucide-react";
import { Section, SectionHeader } from "@/components/Section";
import { FinalCTA } from "@/components/FinalCTA";
import { CTAButton } from "@/components/CTAButton";
import { ProgramIntakeModal, PROGRAM_OPTIONS } from "@/components/ProgramIntakeModal";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/programs")({
  head: () => ({
    meta: [
      { title: "Programs — University Accelerator, Personalized Pathway & Skills Studio" },
      {
        name: "description",
        content:
          "Three structured programs for grades 8–12: University Accelerator, Personalized Pathway, and Skills Studio. Find the right fit for your child.",
      },
      { property: "og:title", content: "Programs — The AI Launchpad" },
      {
        property: "og:description",
        content:
          "Three structured AI & coding programs designed for serious students in grades 8–12.",
      },
    ],
  }),
  component: ProgramsPage,
});

type ProgramKey = (typeof PROGRAM_OPTIONS)[number];

interface Program {
  key: ProgramKey;
  icon: typeof Award;
  tag: string;
  title: string;
  brief: string;
  featured?: boolean;
  overview: string;
  who: string;
  outcomes: string[];
  learn: string[];
}

const programs: Program[] = [
  {
    key: "University Accelerator",
    icon: Award,
    tag: "Path 1 · Most Popular",
    title: "University Accelerator",
    brief:
      "Projects, certifications, and a portfolio that helps your child stand out in university applications.",
    featured: true,
    overview:
      "A structured, results-driven program that turns AI and coding skills into a credible university application — through real projects, recognized certifications, and 1:1 mentorship from a Microsoft Certified AI Engineer.",
    who: "Grade 10–12 students (and motivated grade 9s) targeting STEM, business, or design programs in the next 1–3 years.",
    outcomes: [
      "A portfolio of 2–4 real AI & coding projects",
      "Microsoft & Google AI certifications",
      "A measurable edge over applicants with the same grades",
      "Confidence in interviews, supplementals, and tech competitions",
    ],
    learn: [
      "Foundations of AI, machine learning, and modern coding",
      "Project planning, execution, and presentation",
      "Industry tools — not toy versions",
      "Mentorship around academic direction and project ideas",
    ],
  },
  {
    key: "Personalized Pathway",
    icon: Compass,
    tag: "Path 2",
    title: "Personalized Pathway",
    brief:
      "1:1 coaching built entirely around your child's pace, schedule, and specific goals.",
    overview:
      "Every session is custom-built around where your child is right now — filling gaps, accelerating strengths, and building real confidence with focused 1:1 attention.",
    who: "Students in grades 8–12 who want dedicated 1-on-1 attention, flexible scheduling, or faster progress than a group class allows.",
    outcomes: [
      "A custom plan built in the first session",
      "Faster progress than any group class",
      "A personal capstone project to showcase",
      "Targeted growth on the skills that matter most",
    ],
    learn: [
      "AI tools, Python, or project building — your child chooses",
      "Pacing adjusted to your child's school schedule",
      "Regular check-ins to keep momentum",
      "Direct mentorship every session",
    ],
  },
  {
    key: "Skills Studio",
    icon: Layers,
    tag: "Path 3",
    title: "Skills Studio",
    brief:
      "A clear, structured starting point for students new to AI and coding.",
    overview:
      "Skills Studio gives students a clear ladder. They start where they are, build confidence with hands-on mini-projects, and steadily move into deeper, more applied work.",
    who: "Students in grades 8–10 who are new to coding or AI and want a structured, supportive environment to build a real foundation.",
    outcomes: [
      "Real understanding of how AI works — and how to use it",
      "Python and coding fundamentals through mini-projects",
      "Confident progression: Beginner → Intermediate → Expert",
      "The vocabulary and mindset to thrive in any future tech path",
    ],
    learn: [
      "Beginner, Intermediate, and Expert level classes",
      "Short, focused topics taught by industry instructors",
      "A natural progression through skill levels",
      "Mini-projects at the Expert level",
    ],
  },
];

function ProgramsPage() {
  const [openKey, setOpenKey] = useState<ProgramKey | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalProgram, setModalProgram] = useState<ProgramKey>(PROGRAM_OPTIONS[0]);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const toggle = (key: ProgramKey) => {
    setOpenKey((cur) => (cur === key ? null : key));
  };

  useEffect(() => {
    if (!openKey) return;
    // Wait for accordion to expand, then scroll into view
    const t = setTimeout(() => {
      const el = cardRefs.current[openKey];
      if (el) {
        const top = el.getBoundingClientRect().top + window.scrollY - 96;
        window.scrollTo({ top, behavior: "smooth" });
      }
    }, 250);
    return () => clearTimeout(t);
  }, [openKey]);

  const openModal = (key: ProgramKey) => {
    setModalProgram(key);
    setModalOpen(true);
  };

  return (
    <>
      {/* Compact intro + program cards (above the fold) */}
      <section className="bg-surface-muted border-b border-border">
        <div className="container-prose pt-8 pb-4 sm:pt-10 max-w-4xl text-center">
          <span className="eyebrow">Programs</span>
          <h1 className="mt-2 text-2xl sm:text-3xl font-semibold tracking-tight">
            Three clear paths. One that's right for your child.
          </h1>
        </div>
      </section>

      <Section bg="muted" className="pt-6 sm:pt-8">
        <div className="flex flex-col gap-5 sm:gap-6">
          {programs.map((p) => {
            const isOpen = openKey === p.key;
            return (
              <div
                key={p.key}
                ref={(el) => {
                  cardRefs.current[p.key] = el;
                }}
                className={cn(
                  "group relative rounded-2xl border bg-surface transition-all duration-300",
                  "md:hover:-translate-y-1 md:hover:shadow-xl md:hover:bg-surface",
                  isOpen
                    ? "border-secondary/60 shadow-xl ring-1 ring-secondary/30"
                    : "border-border shadow-sm md:hover:border-primary/30",
                  p.featured && !isOpen && "border-secondary/40 ring-1 ring-secondary/20",
                )}
              >
                {p.featured && (
                  <div className="absolute -top-3 left-6 inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1 text-xs font-semibold text-secondary-foreground shadow">
                    <Star className="h-3.5 w-3.5 fill-current" /> Most Popular
                  </div>
                )}

                {/* Summary (clickable) */}
                <button
                  type="button"
                  onClick={() => toggle(p.key)}
                  aria-expanded={isOpen}
                  aria-controls={`program-${p.key}`}
                  className="flex w-full items-start gap-5 p-6 text-left sm:p-8"
                >
                  <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground sm:h-14 sm:w-14">
                    <p.icon className="h-6 w-6 sm:h-7 sm:w-7" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-xs font-semibold uppercase tracking-wider text-secondary">
                      {p.tag}
                    </span>
                    <h2 className="h3 mt-1.5 sm:text-2xl">{p.title}</h2>
                    <p className="mt-2 text-foreground/75">{p.brief}</p>
                    <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                      {p.outcomes.slice(0, 4).map((it) => (
                        <li key={it} className="flex items-start gap-2 text-sm text-foreground/85">
                          <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-secondary" />
                          <span>{it}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="mt-4 flex flex-wrap items-center gap-3">
                      <span
                        onClick={(e) => {
                          e.stopPropagation();
                          openModal(p.key);
                        }}
                        className="inline-flex items-center gap-1.5 rounded-md bg-secondary px-4 py-2 text-sm font-semibold text-secondary-foreground transition hover:bg-secondary/90"
                      >
                        Learn more <ArrowRight className="h-4 w-4" />
                      </span>
                      <span className="inline-flex items-center gap-1 text-sm font-medium text-primary/80">
                        {isOpen ? "Hide details" : "View details"}
                        <ChevronDown
                          className={cn(
                            "h-4 w-4 transition-transform duration-300",
                            isOpen && "rotate-180",
                          )}
                        />
                      </span>
                    </div>
                  </div>
                </button>

                {/* Expandable detail */}
                <div
                  id={`program-${p.key}`}
                  className={cn(
                    "grid transition-all duration-500 ease-out",
                    isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                  )}
                >
                  <div className="overflow-hidden">
                    <div className="border-t border-border px-6 pb-8 pt-6 sm:px-8">
                      <div className="grid gap-8 lg:grid-cols-2">
                        <div>
                          <h3 className="text-sm font-semibold uppercase tracking-wider text-secondary">
                            Overview
                          </h3>
                          <p className="mt-3 text-foreground/80 leading-relaxed">{p.overview}</p>
                          <h3 className="mt-6 text-sm font-semibold uppercase tracking-wider text-secondary">
                            Who it's for
                          </h3>
                          <p className="mt-3 text-foreground/80 leading-relaxed">{p.who}</p>
                        </div>
                        <div className="space-y-6">
                          <Block title="Outcomes" items={p.outcomes} />
                          <Block title="What they learn" items={p.learn} />
                        </div>
                      </div>

                      <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <p className="text-sm text-muted-foreground">
                          Want to talk it through? Request info and we'll follow up within a business day.
                        </p>
                        <button
                          type="button"
                          onClick={() => openModal(p.key)}
                          className="inline-flex items-center justify-center gap-2 rounded-md bg-secondary px-5 py-3 text-sm font-semibold text-secondary-foreground shadow-sm transition hover:bg-secondary/90 focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        >
                          Learn more about {p.title} <ArrowRight className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </Section>

      <FinalCTA />

      <ProgramIntakeModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        defaultProgram={modalProgram}
      />
    </>
  );
}

function Block({ title, items }: { title: string; items: string[] }) {
  return (
    <div>
      <h3 className="text-sm font-semibold uppercase tracking-wider text-secondary">{title}</h3>
      <ul className="mt-3 space-y-2.5">
        {items.map((it) => (
          <li key={it} className="flex items-start gap-2.5">
            <CheckCircle2 className="mt-0.5 h-5 w-5 flex-shrink-0 text-secondary" />
            <span className="text-foreground/85">{it}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
