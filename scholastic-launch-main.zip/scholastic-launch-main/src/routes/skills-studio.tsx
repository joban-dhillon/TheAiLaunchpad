import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowRight } from "lucide-react";
import { FinalCTA } from "@/components/FinalCTA";
import { CourseEnquiryModal } from "@/components/CourseEnquiryModal";
import { CourseDetailModal } from "@/components/CourseDetailModal";
import { COURSES, type Course, type CourseLevel } from "@/data/skills-courses";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/skills-studio")({
  head: () => ({
    meta: [
      { title: "Skills Studio — Beginner, Intermediate & Expert AI/Coding Courses" },
      {
        name: "description",
        content:
          "Browse Skills Studio courses for grades 8–12. Filter by level — Beginner, Intermediate, or Expert — and find the right starting point.",
      },
      { property: "og:title", content: "Skills Studio — The AI Launchpad" },
      {
        property: "og:description",
        content: "Level-based AI and coding courses for serious students in grades 8–12.",
      },
    ],
  }),
  component: SkillsStudioPage,
});

type Filter = "All" | CourseLevel;
const FILTERS: Filter[] = ["All", "Beginner", "Intermediate", "Expert"];

const levelBadge: Record<CourseLevel, string> = {
  Beginner: "bg-emerald-100 text-emerald-700 ring-1 ring-emerald-200",
  Intermediate: "bg-blue-100 text-blue-700 ring-1 ring-blue-200",
  Expert: "bg-purple-100 text-purple-700 ring-1 ring-purple-200",
};

function SkillsStudioPage() {
  const [filter, setFilter] = useState<Filter>("All");
  const [detailCourse, setDetailCourse] = useState<Course | null>(null);
  const [enquiryCourse, setEnquiryCourse] = useState<Course | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [enquiryOpen, setEnquiryOpen] = useState(false);

  const visible = useMemo(
    () => (filter === "All" ? COURSES : COURSES.filter((c) => c.level === filter)),
    [filter],
  );

  const openDetail = (c: Course) => {
    setDetailCourse(c);
    setDetailOpen(true);
  };

  const openEnquiry = (c: Course) => {
    setEnquiryCourse(c);
    setEnquiryOpen(true);
  };

  const fromDetailToEnquiry = () => {
    if (detailCourse) {
      setDetailOpen(false);
      setTimeout(() => openEnquiry(detailCourse), 150);
    }
  };

  return (
    <>
      {/* Compact intro + filters (above the fold) */}
      <section className="border-b border-border bg-surface-muted">
        <div className="container-prose pt-8 pb-6 sm:pt-10 max-w-5xl">
          <div className="text-center">
            <span className="eyebrow">Skills Studio</span>
            <h1 className="mt-2 text-2xl sm:text-3xl font-semibold tracking-tight">
              Browse courses by level. Start where your child is.
            </h1>
          </div>

          {/* Filter tabs */}
          <div
            role="tablist"
            aria-label="Filter courses by level"
            className="mt-6 flex flex-wrap justify-center gap-2"
          >
            {FILTERS.map((f) => {
              const active = filter === f;
              return (
                <button
                  key={f}
                  role="tab"
                  aria-selected={active}
                  onClick={() => setFilter(f)}
                  className={cn(
                    "rounded-full px-4 py-1.5 text-sm font-medium transition-colors",
                    active
                      ? "bg-foreground/85 text-background"
                      : "bg-muted text-muted-foreground hover:bg-muted/70 hover:text-foreground",
                  )}
                >
                  {f}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Course cards */}
      <section className="bg-surface-muted">
        <div className="container-prose max-w-5xl py-8 sm:py-12">
          {visible.length === 0 ? (
            <p className="text-center text-muted-foreground">No courses in this level yet.</p>
          ) : (
            <div className="grid gap-5 sm:grid-cols-2">
              {visible.map((c) => (
                <article
                  key={c.id}
                  className="relative flex flex-col rounded-2xl border border-border bg-surface p-6 shadow-sm transition-all duration-300 md:hover:-translate-y-1 md:hover:border-primary/30 md:hover:shadow-md"
                >
                  <span
                    className={cn(
                      "absolute right-5 top-5 rounded-full px-2.5 py-0.5 text-xs font-semibold",
                      levelBadge[c.level],
                    )}
                  >
                    {c.level}
                  </span>

                  <h2 className="h3 pr-24 text-xl">{c.title}</h2>
                  <p className="mt-2 text-sm text-foreground/75 leading-relaxed">
                    {c.description}
                  </p>
                  <p className="mt-3 text-xs font-medium text-muted-foreground">{c.duration}</p>

                  <div className="mt-5 flex flex-1 items-end gap-2">
                    <button
                      type="button"
                      onClick={() => openDetail(c)}
                      className="inline-flex items-center justify-center gap-1 rounded-md border border-border bg-surface px-4 py-2 text-sm font-medium text-foreground transition hover:border-primary/30 hover:bg-muted/50"
                    >
                      Learn More
                    </button>
                    <button
                      type="button"
                      onClick={() => openEnquiry(c)}
                      className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-md bg-secondary px-4 py-2 text-sm font-semibold text-secondary-foreground shadow-sm transition hover:bg-secondary/90"
                    >
                      Enquire <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>

      <FinalCTA
        title="Not sure which course is right?"
        description="Book a free session — we'll talk through your child's interests and recommend the right starting point."
      />

      <CourseDetailModal
        open={detailOpen}
        onOpenChange={setDetailOpen}
        course={detailCourse}
        onEnquire={fromDetailToEnquiry}
      />
      <CourseEnquiryModal
        open={enquiryOpen}
        onOpenChange={setEnquiryOpen}
        course={enquiryCourse?.title ?? ""}
      />
    </>
  );
}
