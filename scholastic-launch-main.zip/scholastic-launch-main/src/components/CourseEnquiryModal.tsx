import { useEffect, useState } from "react";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";

const GRADES = ["Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"] as const;

const schema = z.object({
  studentName: z.string().trim().min(1, "Student name is required").max(80),
  parentName: z.string().trim().min(1, "Parent name is required").max(80),
  email: z.string().trim().email("Valid email required").max(120),
  phone: z.string().trim().min(7, "Valid phone required").max(20),
  grade: z.string().min(1, "Select a grade"),
  course: z.string().min(1, "Course required"),
});

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  course: string;
}

export function CourseEnquiryModal({ open, onOpenChange, course }: Props) {
  const [grade, setGrade] = useState<string>(GRADES[0]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (!open) {
      setTimeout(() => {
        setSubmitted(false);
        setErrors({});
      }, 200);
    }
  }, [open]);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const data = {
      studentName: String(fd.get("studentName") ?? ""),
      parentName: String(fd.get("parentName") ?? ""),
      email: String(fd.get("email") ?? ""),
      phone: String(fd.get("phone") ?? ""),
      grade,
      course,
    };
    const result = schema.safeParse(data);
    if (!result.success) {
      const errs: Record<string, string> = {};
      result.error.issues.forEach((i) => {
        errs[i.path[0] as string] = i.message;
      });
      setErrors(errs);
      return;
    }
    setErrors({});
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 700));
    setSubmitting(false);
    setSubmitted(true);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        {submitted ? (
          <div className="py-8 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-secondary/15 text-secondary">
              <CheckCircle2 className="h-7 w-7" />
            </div>
            <DialogHeader className="mt-5">
              <DialogTitle className="text-center">Enquiry sent — thank you!</DialogTitle>
              <DialogDescription className="text-center">
                We've received your enquiry for <strong>{course}</strong>. A program advisor will
                reach out within one business day.
              </DialogDescription>
            </DialogHeader>
            <div className="mt-6">
              <Button onClick={() => onOpenChange(false)}>Close</Button>
            </div>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>Enquire about this course</DialogTitle>
              <DialogDescription>
                Share a few details and we'll follow up with class schedules and next steps.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={onSubmit} className="mt-2 space-y-4">
              <Field label="Selected course" id="course">
                <Input id="course" name="course" value={course} readOnly className="bg-muted" />
              </Field>

              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Student name" id="studentName" required error={errors.studentName}>
                  <Input id="studentName" name="studentName" autoComplete="off" />
                </Field>
                <Field label="Parent name" id="parentName" required error={errors.parentName}>
                  <Input id="parentName" name="parentName" autoComplete="name" />
                </Field>
                <Field label="Email" id="email" required error={errors.email}>
                  <Input id="email" name="email" type="email" autoComplete="email" />
                </Field>
                <Field label="Phone number" id="phone" required error={errors.phone}>
                  <Input id="phone" name="phone" type="tel" autoComplete="tel" />
                </Field>
              </div>

              <Field label="Grade" id="grade" required error={errors.grade}>
                <select
                  id="grade"
                  value={grade}
                  onChange={(e) => setGrade(e.target.value)}
                  className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                >
                  {GRADES.map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
              </Field>

              <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={submitting}
                  className="bg-secondary text-secondary-foreground hover:bg-secondary/90"
                >
                  {submitting ? "Sending…" : "Send Enquiry"}
                </Button>
              </div>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  id,
  required,
  error,
  children,
}: {
  label: string;
  id: string;
  required?: boolean;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <Label htmlFor={id} className="text-sm font-medium">
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <div className="mt-1.5">{children}</div>
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}
