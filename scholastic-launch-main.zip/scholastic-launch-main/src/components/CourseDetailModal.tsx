import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Clock, Wrench, Target } from "lucide-react";
import type { Course } from "@/data/skills-courses";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  course: Course | null;
  onEnquire: () => void;
}

const levelStyles: Record<Course["level"], string> = {
  Beginner: "bg-emerald-100 text-emerald-700 ring-1 ring-emerald-200",
  Intermediate: "bg-blue-100 text-blue-700 ring-1 ring-blue-200",
  Expert: "bg-purple-100 text-purple-700 ring-1 ring-purple-200",
};

export function CourseDetailModal({ open, onOpenChange, course, onEnquire }: Props) {
  if (!course) return null;
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <span
            className={`inline-flex w-fit items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${levelStyles[course.level]}`}
          >
            {course.level}
          </span>
          <DialogTitle className="mt-2 text-2xl">{course.title}</DialogTitle>
          <DialogDescription>{course.description}</DialogDescription>
        </DialogHeader>

        <div className="mt-2 grid gap-4 sm:grid-cols-2">
          <InfoBox icon={Clock} label="Duration" value={course.duration} />
          <InfoBox icon={Target} label="Level" value={course.level} />
        </div>

        <Section title="Topics covered" items={course.topics} />
        <Section title="What they'll build" items={course.builds} icon={Wrench} />
        <Section title="Outcomes" items={course.outcomes} />

        <div className="mt-2 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button
            onClick={onEnquire}
            className="bg-secondary text-secondary-foreground hover:bg-secondary/90"
          >
            Enquire about this course
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function InfoBox({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Clock;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/40 px-4 py-3">
      <Icon className="h-5 w-5 text-secondary" />
      <div>
        <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
        <p className="text-sm font-medium text-foreground">{value}</p>
      </div>
    </div>
  );
}

function Section({
  title,
  items,
  icon: Icon = CheckCircle2,
}: {
  title: string;
  items: string[];
  icon?: typeof CheckCircle2;
}) {
  return (
    <div>
      <h3 className="text-sm font-semibold uppercase tracking-wider text-secondary">{title}</h3>
      <ul className="mt-2 space-y-2">
        {items.map((it) => (
          <li key={it} className="flex items-start gap-2.5 text-sm text-foreground/85">
            <Icon className="mt-0.5 h-4 w-4 flex-shrink-0 text-secondary" />
            <span>{it}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
