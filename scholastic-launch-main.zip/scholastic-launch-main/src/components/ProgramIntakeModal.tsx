import { useEffect, useState } from "react";
import { z } from "zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";

export const PROGRAM_OPTIONS = [
  "University Accelerator",
  "Personalized Pathway",
  "Skills Studio",
] as const;

const INTERESTS = [
  "Online classes",
  "In-person classes",
  "Certifications",
  "1:1 support",
  "Project-based learning",
  "University application support",
] as const;

const schema = z.object({
  studentName: z.string().trim().min(1, "Student name is required").max(80),
  parentName: z.string().trim().min(1, "Parent name is required").max(80),
  phone: z.string().trim().min(7, "Valid phone required").max(20),
  email: z.string().trim().email("Valid email required").max(120),
  program: z.string().min(1, "Select a program"),
  contactMethod: z.enum(["WhatsApp", "Call"]),
  preferredTime: z.string().trim().max(80).optional().or(z.literal("")),
  message: z.string().trim().max(600).optional().or(z.literal("")),
});

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultProgram?: string;
}

export function ProgramIntakeModal({ open, onOpenChange, defaultProgram }: Props) {
  const [program, setProgram] = useState(defaultProgram ?? PROGRAM_OPTIONS[0]);
  const [contactMethod, setContactMethod] = useState<"WhatsApp" | "Call">("WhatsApp");
  const [interests, setInterests] = useState<string[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (open && defaultProgram) setProgram(defaultProgram);
    if (!open) {
      // reset on close
      setTimeout(() => {
        setSubmitted(false);
        setErrors({});
        setInterests([]);
      }, 200);
    }
  }, [open, defaultProgram]);

  const toggleInterest = (val: string) => {
    setInterests((cur) => (cur.includes(val) ? cur.filter((x) => x !== val) : [...cur, val]));
  };

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const data = {
      studentName: String(fd.get("studentName") ?? ""),
      parentName: String(fd.get("parentName") ?? ""),
      phone: String(fd.get("phone") ?? ""),
      email: String(fd.get("email") ?? ""),
      program,
      contactMethod,
      preferredTime: String(fd.get("preferredTime") ?? ""),
      message: String(fd.get("message") ?? ""),
    };
    const result = schema.safeParse(data);
    if (!result.success) {
      const errs: Record<string, string> = {};
      result.error.issues.forEach((i) => {
        errs[i.path[0] as string] = i.message;
      });
      setErrors(errs);
      return;
    }
    setErrors({});
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 700));
    setSubmitting(false);
    setSubmitted(true);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        {submitted ? (
          <div className="py-8 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-secondary/15 text-secondary">
              <CheckCircle2 className="h-7 w-7" />
            </div>
            <DialogHeader className="mt-5">
              <DialogTitle className="text-center">Thanks — we'll be in touch soon.</DialogTitle>
              <DialogDescription className="text-center">
                A program advisor will contact you within one business day to schedule your free session.
              </DialogDescription>
            </DialogHeader>
            <div className="mt-6">
              <Button onClick={() => onOpenChange(false)}>Close</Button>
            </div>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>Request program info</DialogTitle>
              <DialogDescription>
                Tell us a little about your child and we'll follow up with the right next step.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={onSubmit} className="mt-2 space-y-5">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Student name" id="studentName" error={errors.studentName} required>
                  <Input id="studentName" name="studentName" autoComplete="off" />
                </Field>
                <Field label="Parent name" id="parentName" error={errors.parentName} required>
                  <Input id="parentName" name="parentName" autoComplete="name" />
                </Field>
                <Field label="Phone number" id="phone" error={errors.phone} required>
                  <Input id="phone" name="phone" type="tel" autoComplete="tel" />
                </Field>
                <Field label="Email" id="email" error={errors.email} required>
                  <Input id="email" name="email" type="email" autoComplete="email" />
                </Field>
              </div>

              <Field label="Program" id="program" error={errors.program} required>
                <select
                  id="program"
                  value={program}
                  onChange={(e) => setProgram(e.target.value)}
                  className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                >
                  {PROGRAM_OPTIONS.map((p) => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
              </Field>

              <div>
                <Label className="text-sm font-medium">Preferred method of communication</Label>
                <div className="mt-2 flex gap-2">
                  {(["WhatsApp", "Call"] as const).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setContactMethod(m)}
                      className={`rounded-md border px-4 py-2 text-sm font-medium transition ${
                        contactMethod === m
                          ? "border-secondary bg-secondary/10 text-secondary"
                          : "border-border bg-surface text-foreground/70 hover:border-primary/40"
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <Field label="Preferred time" id="preferredTime">
                <Input
                  id="preferredTime"
                  name="preferredTime"
                  placeholder="e.g. Weekday evenings or Sat mornings"
                />
              </Field>

              <div>
                <Label className="text-sm font-medium text-foreground/70">
                  I'm also interested in (optional)
                </Label>
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  {INTERESTS.map((it) => {
                    const active = interests.includes(it);
                    return (
                      <label
                        key={it}
                        className={`flex cursor-pointer items-center gap-2 rounded-md border px-3 py-2 text-sm transition ${
                          active
                            ? "border-secondary/50 bg-secondary/5 text-foreground"
                            : "border-border bg-surface/60 text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        <Checkbox checked={active} onCheckedChange={() => toggleInterest(it)} />
                        <span>{it}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <Field label="Anything else? (optional)" id="message">
                <Textarea id="message" name="message" rows={3} placeholder="Goals, questions, or context" />
              </Field>

              <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={submitting} className="bg-secondary text-secondary-foreground hover:bg-secondary/90">
                  {submitting ? "Sending…" : "Submit request"}
                </Button>
              </div>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  id,
  required,
  error,
  children,
}: {
  label: string;
  id: string;
  required?: boolean;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <Label htmlFor={id} className="text-sm font-medium">
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <div className="mt-1.5">{children}</div>
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}
