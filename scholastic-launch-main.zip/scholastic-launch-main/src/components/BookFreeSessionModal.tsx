import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";

const GRADES = ["Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"] as const;
const CONTACT_METHODS = ["WhatsApp", "Text", "Call"] as const;

const schema = z.object({
  studentName: z.string().trim().min(1, "Student name is required").max(80),
  parentName: z.string().trim().min(1, "Parent name is required").max(80),
  phone: z.string().trim().min(7, "Valid phone required").max(20),
  email: z.string().trim().email("Valid email required").max(120),
  grade: z.string().min(1, "Select a grade"),
  contactMethod: z.string().min(1, "Select a contact method"),
});

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function BookFreeSessionModal({ open, onOpenChange }: Props) {
  const [grade, setGrade] = useState<string>(GRADES[0]);
  const [contactMethod, setContactMethod] = useState<string>("WhatsApp");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (!open) {
      setTimeout(() => {
        setSubmitted(false);
        setErrors({});
      }, 200);
    }
  }, [open]);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const data = {
      studentName: String(fd.get("studentName") ?? ""),
      parentName: String(fd.get("parentName") ?? ""),
      phone: String(fd.get("phone") ?? ""),
      email: String(fd.get("email") ?? ""),
      grade,
      contactMethod,
    };
    const result = schema.safeParse(data);
    if (!result.success) {
      const errs: Record<string, string> = {};
      result.error.issues.forEach((i) => {
        errs[i.path[0] as string] = i.message;
      });
      setErrors(errs);
      return;
    }
    setErrors({});
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 700));
    setSubmitting(false);
    setSubmitted(true);
  };

  const selectClass =
    "flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        {submitted ? (
          <div className="py-8 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-secondary/15 text-secondary">
              <CheckCircle2 className="h-7 w-7" />
            </div>
            <DialogHeader className="mt-5">
              <DialogTitle className="text-center">You're booked — thank you!</DialogTitle>
              <DialogDescription className="text-center">
                We've received your free session request. A program advisor will reach out within
                one business day using your preferred method of contact.
              </DialogDescription>
            </DialogHeader>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>Book a Free Session</DialogTitle>
              <DialogDescription>
                Share a few details and we'll follow up to confirm your free discovery session.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={onSubmit} className="mt-2 space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Student name" id="studentName" required error={errors.studentName}>
                  <Input id="studentName" name="studentName" autoComplete="off" />
                </Field>
                <Field label="Parent name" id="parentName" required error={errors.parentName}>
                  <Input id="parentName" name="parentName" autoComplete="name" />
                </Field>
                <Field label="Phone number" id="phone" required error={errors.phone}>
                  <Input id="phone" name="phone" type="tel" autoComplete="tel" />
                </Field>
                <Field label="Email" id="email" required error={errors.email}>
                  <Input id="email" name="email" type="email" autoComplete="email" />
                </Field>
              </div>

              <Field label="Student grade" id="grade" required error={errors.grade}>
                <select
                  id="grade"
                  value={grade}
                  onChange={(e) => setGrade(e.target.value)}
                  className={selectClass}
                >
                  {GRADES.map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
              </Field>

              <Field
                label="Preferred method of communication"
                id="contactMethod"
                required
                error={errors.contactMethod}
              >
                <div className="inline-flex w-full rounded-md border border-input p-1 bg-muted/30" role="group">
                  {CONTACT_METHODS.map((m) => {
                    const selected = contactMethod === m;
                    return (
                      <button
                        key={m}
                        type="button"
                        onClick={() => setContactMethod(m)}
                        aria-pressed={selected}
                        className={`flex-1 rounded px-3 py-2 text-sm font-medium transition-colors ${
                          selected
                            ? "bg-primary text-primary-foreground shadow-sm"
                            : "bg-transparent text-foreground/50 hover:text-foreground/80"
                        }`}
                      >
                        {m}
                      </button>
                    );
                  })}
                </div>
              </Field>

              <div className="flex justify-end pt-2">
                <Button
                  type="submit"
                  disabled={submitting}
                  className="bg-secondary text-secondary-foreground hover:bg-secondary/90"
                >
                  {submitting ? "Sending…" : "Book My Free Session"}
                </Button>
              </div>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  id,
  required,
  error,
  children,
}: {
  label: string;
  id: string;
  required?: boolean;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <Label htmlFor={id} className="text-sm font-medium">
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <div className="mt-1.5">{children}</div>
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}

// ---------- Global provider so any component can open the modal ----------

interface BookFreeSessionContextValue {
  open: () => void;
}

const BookFreeSessionContext = createContext<BookFreeSessionContextValue | null>(null);

export function BookFreeSessionProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const open = useCallback(() => setIsOpen(true), []);
  return (
    <BookFreeSessionContext.Provider value={{ open }}>
      {children}
      <BookFreeSessionModal open={isOpen} onOpenChange={setIsOpen} />
    </BookFreeSessionContext.Provider>
  );
}

export function useBookFreeSession() {
  const ctx = useContext(BookFreeSessionContext);
  if (!ctx) throw new Error("useBookFreeSession must be used inside BookFreeSessionProvider");
  return ctx;
}
