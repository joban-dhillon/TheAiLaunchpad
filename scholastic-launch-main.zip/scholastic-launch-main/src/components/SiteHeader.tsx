import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Menu, X, GraduationCap, ChevronDown } from "lucide-react";
import { useBookFreeSession } from "@/components/BookFreeSessionModal";

const nav = [
  { to: "/", label: "Home" },
  { to: "/programs", label: "Programs" },
  { to: "/skills-studio", label: "Skills Studio" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const aboutRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { open: openBookSession } = useBookFreeSession();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isAboutRoute = pathname === "/about" || pathname.startsWith("/about");

  // Keep dropdown open while on About route
  useEffect(() => {
    if (isAboutRoute) setAboutOpen(true);
    else setAboutOpen(false);
  }, [isAboutRoute]);

  // Close on outside click (but not when on About route)
  useEffect(() => {
    if (!aboutOpen) return;
    const handler = (e: MouseEvent) => {
      if (isAboutRoute) return;
      if (aboutRef.current && !aboutRef.current.contains(e.target as Node)) {
        setAboutOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [aboutOpen, isAboutRoute]);

  const goToFaqs = (closeMenu?: () => void) => {
    closeMenu?.();
    if (typeof window !== "undefined" && window.location.pathname === "/about") {
      document.getElementById("parent-faqs")?.scrollIntoView({ behavior: "smooth" });
      history.replaceState(null, "", "#parent-faqs");
    } else {
      navigate({ to: "/about", hash: "parent-faqs" });
    }
  };

  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur">
      <div className="container-prose flex h-16 items-center justify-between sm:h-20">
        <Link to="/" className="flex items-center gap-2.5" onClick={() => setOpen(false)}>
          <span className="flex h-9 w-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <GraduationCap className="h-5 w-5" />
          </span>
          <span className="font-display text-lg font-semibold text-primary">
            The AI Launchpad
          </span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {nav.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="text-sm font-medium text-foreground/75 transition-colors hover:text-primary"
              activeProps={{ className: "text-primary" }}
              activeOptions={{ exact: item.to === "/" }}
            >
              {item.label}
            </Link>
          ))}

          {/* About dropdown */}
          <div className="relative" ref={aboutRef}>
            <button
              type="button"
              className={`inline-flex items-center gap-1 text-sm font-medium transition-colors hover:text-primary ${
                isAboutRoute ? "text-primary" : "text-foreground/75"
              }`}
              onClick={() => setAboutOpen((v) => !v)}
              aria-haspopup="menu"
              aria-expanded={aboutOpen}
            >
              About
              <ChevronDown className={`h-3.5 w-3.5 transition-transform ${aboutOpen ? "rotate-180" : ""}`} />
            </button>
            {aboutOpen && (
              <div
                role="menu"
                className="absolute left-1/2 top-full z-50 mt-2 w-52 -translate-x-1/2 overflow-hidden rounded-lg border border-border bg-surface shadow-lg"
              >
                <Link
                  to="/about"
                  onClick={() => !isAboutRoute && setAboutOpen(false)}
                  className="block px-4 py-3 text-sm font-medium text-foreground/80 hover:bg-muted hover:text-primary"
                >
                  About Us
                </Link>
                <button
                  type="button"
                  onClick={() => goToFaqs()}
                  className="block w-full text-left px-4 py-3 text-sm font-medium text-foreground/80 hover:bg-muted hover:text-primary"
                >
                  Parent FAQs
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={openBookSession}
            className="rounded-md bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-sm transition hover:bg-primary/90"
          >
            Book Free Session
          </button>
        </nav>

        <button
          type="button"
          aria-label="Toggle menu"
          aria-expanded={open}
          className="inline-flex h-10 w-10 items-center justify-center rounded-md border border-border md:hidden touch-manipulation active:bg-muted"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-border bg-surface md:hidden animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="container-prose flex flex-col gap-1 py-3">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="rounded-md px-3 py-3 text-base font-medium text-foreground/80 hover:bg-muted"
                activeProps={{ className: "text-primary bg-muted" }}
                activeOptions={{ exact: item.to === "/" }}
              >
                {item.label}
              </Link>
            ))}
            <Link
              to="/about"
              onClick={() => setOpen(false)}
              className="rounded-md px-3 py-3 text-base font-medium text-foreground/80 hover:bg-muted"
              activeProps={{ className: "text-primary bg-muted" }}
            >
              About Us
            </Link>
            <button
              type="button"
              onClick={() => goToFaqs(() => setOpen(false))}
              className="rounded-md px-3 py-3 text-left text-base font-medium text-foreground/80 hover:bg-muted"
            >
              Parent FAQs
            </button>
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                openBookSession();
              }}
              className="mt-2 rounded-md bg-primary px-4 py-3 text-center text-base font-semibold text-primary-foreground"
            >
              Book Free Session
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
