import { ArrowRight } from "lucide-react";
import { useBookFreeSession } from "@/components/BookFreeSessionModal";

export function FinalCTA({
  title = "Not sure where your child should start?",
  description = "Book a free session with our team. We'll help you choose the right path based on your child's grade, interests, and goals.",
  cta = "Book a Free Session",
}: {
  title?: string;
  description?: string;
  cta?: string;
}) {
  const { open } = useBookFreeSession();
  return (
    <section className="section">
      <div className="container-prose">
        <div className="relative overflow-hidden rounded-2xl bg-primary px-6 py-14 text-center sm:px-12 sm:py-20">
          <div
            aria-hidden
            className="absolute inset-0 opacity-[0.07]"
            style={{
              backgroundImage:
                "radial-gradient(circle at 20% 20%, white 1px, transparent 1px), radial-gradient(circle at 80% 60%, white 1px, transparent 1px)",
              backgroundSize: "32px 32px, 48px 48px",
            }}
          />
          <h2 className="relative h2 text-primary-foreground">{title}</h2>
          <p className="relative mx-auto mt-4 max-w-2xl text-lg text-primary-foreground/85">
            {description}
          </p>
          <div className="relative mt-8 flex justify-center">
            <button
              type="button"
              onClick={open}
              className="inline-flex items-center justify-center gap-2 rounded-md bg-secondary px-7 py-4 text-base font-semibold text-secondary-foreground shadow-sm transition hover:bg-secondary/90 focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-primary"
            >
              {cta}
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
