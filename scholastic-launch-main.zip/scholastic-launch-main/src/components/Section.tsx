import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface Props {
  children: ReactNode;
  className?: string;
  bg?: "default" | "muted" | "primary" | "surface";
  id?: string;
}

const bgs = {
  default: "bg-background",
  muted: "bg-surface-muted",
  surface: "bg-surface",
  primary: "bg-primary text-primary-foreground",
};

export function Section({ children, className, bg = "default", id }: Props) {
  return (
    <section id={id} className={cn("section", bgs[bg], className)}>
      <div className="container-prose">{children}</div>
    </section>
  );
}

export function SectionHeader({
  eyebrow,
  title,
  description,
  align = "left",
  invert = false,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  invert?: boolean;
}) {
  return (
    <div
      className={cn(
        "max-w-3xl",
        align === "center" && "mx-auto text-center",
      )}
    >
      {eyebrow && <span className="eyebrow">{eyebrow}</span>}
      <h2 className={cn("h2 mt-4", invert && "text-primary-foreground")}>{title}</h2>
      {description && (
        <p className={cn("lede mt-4", invert && "text-primary-foreground/80")}>
          {description}
        </p>
      )}
    </div>
  );
}
