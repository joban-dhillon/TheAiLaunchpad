import { Link } from "@tanstack/react-router";
import { GraduationCap, Mail, Phone, MapPin } from "lucide-react";
import { useBookFreeSession } from "@/components/BookFreeSessionModal";

export function SiteFooter() {
  const { open: openBookSession } = useBookFreeSession();
  return (
    <footer className="mt-16 border-t border-border bg-surface-muted">
      <div className="container-prose grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <GraduationCap className="h-5 w-5" />
            </span>
            <span className="font-display text-lg font-semibold text-primary">
              The AI Launchpad
            </span>
          </div>
          <p className="mt-4 max-w-xs text-sm text-muted-foreground">
            An after-school AI and coding institute helping students in grades 8–12 build
            real, future-ready skills.
          </p>
        </div>

        <div>
          <h4 className="text-sm font-semibold uppercase tracking-wider text-primary">
            Explore
          </h4>
          <ul className="mt-4 space-y-2.5 text-sm text-foreground/80">
            <li><Link to="/" className="hover:text-primary">Home</Link></li>
            <li><Link to="/programs" className="hover:text-primary">Programs</Link></li>
            <li><Link to="/skills-studio" className="hover:text-primary">Skills Studio</Link></li>
            <li><Link to="/about" className="hover:text-primary">About</Link></li>
            <li><button type="button" onClick={openBookSession} className="hover:text-primary">Free Session</button></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold uppercase tracking-wider text-primary">
            Contact
          </h4>
          <ul className="mt-4 space-y-2.5 text-sm text-foreground/80">
            <li className="flex items-start gap-2"><Mail className="mt-0.5 h-4 w-4 text-secondary" /><span>hello@theailaunchpad.com</span></li>
            <li className="flex items-start gap-2"><Phone className="mt-0.5 h-4 w-4 text-secondary" /><span>(905) 000-0000</span></li>
            <li className="flex items-start gap-2"><MapPin className="mt-0.5 h-4 w-4 text-secondary" /><span>Brampton, Peel Region & GTA</span></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold uppercase tracking-wider text-primary">
            Service area
          </h4>
          <p className="mt-4 text-sm text-foreground/80">
            Serving students across Brampton, Mississauga, Caledon, and the Greater Toronto Area
            with online and in-person learning options.
          </p>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="container-prose flex flex-col items-center justify-between gap-3 py-6 text-xs text-muted-foreground sm:flex-row">
          <span>© {new Date().getFullYear()} The AI Launchpad. All rights reserved.</span>
          <span>Built for parents. Designed for students.</span>
        </div>
      </div>
    </footer>
  );
}
