import { Link } from "@tanstack/react-router";
import type { ComponentProps } from "react";
import { ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "ghost";

interface Props extends Omit<ComponentProps<typeof Link>, "className"> {
  variant?: Variant;
  className?: string;
  withArrow?: boolean;
  children: React.ReactNode;
}

const styles: Record<Variant, string> = {
  primary:
    "bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm",
  secondary:
    "bg-secondary text-secondary-foreground hover:bg-secondary/90 shadow-sm",
  ghost:
    "bg-surface text-primary border border-border hover:border-primary/40 hover:bg-muted",
};

export function CTAButton({ variant = "primary", className, withArrow, children, ...props }: Props) {
  return (
    <Link
      {...props}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-md px-5 py-3 text-sm sm:text-base font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
        styles[variant],
        className,
      )}
    >
      {children}
      {withArrow && <ArrowRight className="h-4 w-4" />}
    </Link>
  );
}
