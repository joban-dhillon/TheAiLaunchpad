import { useEffect, useState } from "react";

type Slide = { src: string; label: string };

export function HeroSlideshow({ slides, interval = 3000 }: { slides: Slide[]; interval?: number }) {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const id = window.setInterval(() => {
      setActive((i) => (i + 1) % slides.length);
    }, interval);
    return () => window.clearInterval(id);
  }, [slides.length, interval]);

  return (
    <div className="relative">
      <div className="relative aspect-[4/5] w-full overflow-hidden rounded-3xl bg-surface-muted lg:aspect-[5/6]">
        {slides.map((s, i) => (
          <div
            key={s.src}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              i === active ? "opacity-100" : "opacity-0"
            }`}
            aria-hidden={i !== active}
          >
            <img
              src={s.src}
              alt={s.label}
              loading={i === 0 ? "eager" : "lazy"}
              className="h-full w-full object-cover"
            />
            <div
              aria-hidden
              className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-primary/80 via-primary/30 to-transparent"
            />
            <div className="absolute inset-x-0 bottom-0 p-6 sm:p-7">
              <span className="inline-block rounded-full bg-background/15 px-3 py-1 text-sm font-semibold text-primary-foreground backdrop-blur-sm">
                {s.label}
              </span>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 flex items-center justify-center gap-2">
        {slides.map((s, i) => (
          <button
            key={s.src}
            type="button"
            onClick={() => setActive(i)}
            aria-label={`Show slide ${i + 1}: ${s.label}`}
            aria-current={i === active}
            className={`h-1.5 rounded-full transition-all ${
              i === active ? "w-6 bg-primary" : "w-1.5 bg-foreground/25 hover:bg-foreground/40"
            }`}
          />
        ))}
      </div>
    </div>
  );
}
