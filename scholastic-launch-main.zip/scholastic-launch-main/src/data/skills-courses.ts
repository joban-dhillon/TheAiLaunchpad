export type CourseLevel = "Beginner" | "Intermediate" | "Expert";

export interface Course {
  id: string;
  level: CourseLevel;
  title: string;
  description: string;
  duration: string;
  topics: string[];
  builds: string[];
  outcomes: string[];
}

export const COURSES: Course[] = [
  {
    id: "ai-foundations",
    level: "Beginner",
    title: "AI Foundations",
    description:
      "A friendly first step into the world of AI. Students learn how AI actually works and start using it with confidence.",
    duration: "8 weeks · 1 hr/week",
    topics: [
      "What AI really is (in plain language)",
      "How models learn from data",
      "Prompting fundamentals",
      "Using AI tools responsibly",
    ],
    builds: [
      "A personal AI study assistant",
      "An image classifier with no-code tools",
      "A short AI-powered presentation",
    ],
    outcomes: [
      "Confident vocabulary for talking about AI",
      "Hands-on comfort with mainstream AI tools",
      "A clear sense of what to learn next",
    ],
  },
  {
    id: "coding-starter",
    level: "Beginner",
    title: "Coding Starter (Python)",
    description:
      "A structured introduction to Python. Students go from zero to writing real, working programs in a supportive environment.",
    duration: "10 weeks · 1 hr/week",
    topics: [
      "Variables, loops, and functions",
      "Lists, dictionaries, and basic data",
      "Reading and writing files",
      "Debugging like a pro",
    ],
    builds: [
      "A number-guessing game",
      "A simple budget tracker",
      "A text-based adventure",
    ],
    outcomes: [
      "Writes Python programs from scratch",
      "Understands core programming concepts",
      "Ready to take on intermediate projects",
    ],
  },
  {
    id: "applied-ai",
    level: "Intermediate",
    title: "Applied AI with Python",
    description:
      "Students connect coding and AI — using Python to call real AI models and build small, useful projects.",
    duration: "10 weeks · 1.5 hr/week",
    topics: [
      "Working with APIs",
      "Calling LLMs from Python",
      "Structured prompts and outputs",
      "Building small tools end-to-end",
    ],
    builds: [
      "An AI-powered note summarizer",
      "A chatbot with personality",
      "A simple data-analysis script",
    ],
    outcomes: [
      "Combines code and AI confidently",
      "Builds real, working mini-projects",
      "Comfortable reading documentation",
    ],
  },
  {
    id: "web-builder",
    level: "Intermediate",
    title: "Web App Builder",
    description:
      "Students learn to build real web apps using modern tools — and ship something they're proud to share.",
    duration: "10 weeks · 1.5 hr/week",
    topics: [
      "HTML, CSS, and the web platform",
      "JavaScript essentials",
      "Working with components",
      "Deploying a live site",
    ],
    builds: [
      "A personal portfolio site",
      "A small interactive web app",
      "A landing page for a side project",
    ],
    outcomes: [
      "A live website to share",
      "Strong front-end fundamentals",
      "Ready to layer AI features into web apps",
    ],
  },
  {
    id: "ml-projects",
    level: "Expert",
    title: "Machine Learning Projects",
    description:
      "Students take on real ML problems — from data to model to demo — and build portfolio-worthy projects.",
    duration: "12 weeks · 2 hr/week",
    topics: [
      "Data preparation and cleaning",
      "Supervised learning models",
      "Evaluating model quality",
      "Packaging models into demos",
    ],
    builds: [
      "A trained classifier with a live demo",
      "A recommendation mini-engine",
      "A polished project write-up",
    ],
    outcomes: [
      "A real ML project for portfolios",
      "Comfort with the full ML workflow",
      "Strong material for university applications",
    ],
  },
  {
    id: "ai-engineer",
    level: "Expert",
    title: "AI Engineer Track",
    description:
      "An advanced track for serious students — building production-grade AI applications with modern tools and best practices.",
    duration: "12 weeks · 2 hr/week",
    topics: [
      "RAG and vector databases",
      "Agents and tool use",
      "Evaluation and guardrails",
      "Shipping AI features into apps",
    ],
    builds: [
      "A custom RAG-powered assistant",
      "An agent that completes multi-step tasks",
      "A deployed AI app with auth and storage",
    ],
    outcomes: [
      "Builds real AI products end-to-end",
      "Portfolio worthy of competitive programs",
      "Industry-ready engineering habits",
    ],
  },
];
