export const parentFaqs = [
  {
    q: "What age group is The AI Launchpad designed for?",
    a: "Our programs are designed for students in Grades 8–12 (ages 13–18). Whether your child is just starting out or already has some tech experience, we have a level that fits.",
  },
  {
    q: "Does my child need any prior coding or AI experience?",
    a: "Not at all. Our Beginner track starts from scratch. We guide students step by step so no prior experience is needed to get started.",
  },
  {
    q: "Where are the sessions held?",
    a: "We offer both in-person sessions in the Brampton/Peel Region and online sessions for students across the GTA and beyond.",
  },
  {
    q: "How long is each program?",
    a: "Programs typically run 8–12 weeks depending on the track. Each session is 1.5–2 hours, held after school or on weekends.",
  },
  {
    q: "Will my child receive a certificate?",
    a: "Yes! Students who complete the program earn a Microsoft-recognized AI certification that can strengthen their university applications and résumés.",
  },
  {
    q: "How is this different from a regular coding class?",
    a: "We don't just teach syntax — we teach students to build real AI-powered projects, think like innovators, and develop a portfolio. It's career-relevant, not just academic.",
  },
  {
    q: "What is the class size?",
    a: "We keep cohorts small — typically 8–12 students — so every student gets personalized attention and support.",
  },
  {
    q: "How do I enroll my child or learn more?",
    a: "You can book a free discovery session directly on our website, or reach out via the contact form and our team will get back to you within 24 hours.",
  },
];
